import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-12">
        <Link href="/" className="inline-block mb-8">
          <Button variant="outline" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>
        </Link>

        <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Privacy Policy</h1>

          <div className="space-y-6 text-gray-700">
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">Overview</h2>
              <p>
                This Privacy Policy explains how our random video chat service collects, uses, and protects your
                information when you use our platform.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">Information We Collect</h2>
              <p>
                Our service is designed to be anonymous. We do not require you to create an account or provide personal
                information to use the service. However, we do collect:
              </p>
              <ul className="list-disc pl-6 mt-2 space-y-1">
                <li>Technical information such as IP address and browser type</li>
                <li>Usage data such as session duration and features used</li>
                <li>Temporary access to your camera and microphone (with your permission)</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">How We Use Your Information</h2>
              <p>We use the information we collect to:</p>
              <ul className="list-disc pl-6 mt-2 space-y-1">
                <li>Provide and maintain our service</li>
                <li>Improve and optimize our platform</li>
                <li>Monitor and prevent abuse of our service</li>
                <li>Comply with legal obligations</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">Video and Audio Content</h2>
              <p>
                We do not record, store, or monitor your video or audio conversations. All communication happens
                directly between users through peer-to-peer connections. Our servers only facilitate the initial
                connection between users.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">Data Security</h2>
              <p>
                We implement appropriate security measures to protect your information. However, no method of
                transmission over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute
                security.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">Changes to This Policy</h2>
              <p>
                We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new
                Privacy Policy on this page.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-3">Contact Us</h2>
              <p>
                If you have any questions about this Privacy Policy, please contact us at
                privacy@randomvideochat.example.com.
              </p>
            </section>
          </div>
        </div>
      </div>
    </div>
  )
}

