"use client"

import { useEffect, useRef, useState } from "react"
import { io, type Socket } from "socket.io-client"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { X } from "lucide-react"
import ChatMessage from "@/components/chat-message"
import VideoControls from "@/components/video-controls"
import { useToast } from "@/components/ui/use-toast"

type Message = {
  id: string
  text: string
  sender: "me" | "stranger"
  timestamp: Date
}

export default function ChatPage() {
  const { toast } = useToast()
  const [socket, setSocket] = useState<Socket | null>(null)
  const [isConnecting, setIsConnecting] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [isCameraOn, setIsCameraOn] = useState(true)
  const [isMicOn, setIsMicOn] = useState(true)
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [connectionStatus, setConnectionStatus] = useState("Waiting to connect...")

  const localVideoRef = useRef<HTMLVideoElement>(null)
  const remoteVideoRef = useRef<HTMLVideoElement>(null)
  const localStreamRef = useRef<MediaStream | null>(null)
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Initialize socket connection
  useEffect(() => {
    const newSocket = io("https://random-video-chat-server.vercel.app")

    newSocket.on("connect", () => {
      console.log("Socket connected")
      setSocket(newSocket)
    })

    newSocket.on("disconnect", () => {
      console.log("Socket disconnected")
      handleDisconnect()
    })

    return () => {
      newSocket.disconnect()
    }
  }, [])

  // Set up event listeners for WebRTC signaling
  useEffect(() => {
    if (!socket) return

    socket.on("matched", () => {
      setConnectionStatus("Found a match! Connecting...")
      createPeerConnection()
      createOffer()
    })

    socket.on("offer", async (offer: RTCSessionDescriptionInit) => {
      if (!peerConnectionRef.current) {
        createPeerConnection()
      }
      await peerConnectionRef.current?.setRemoteDescription(new RTCSessionDescription(offer))
      createAnswer()
    })

    socket.on("answer", async (answer: RTCSessionDescriptionInit) => {
      await peerConnectionRef.current?.setRemoteDescription(new RTCSessionDescription(answer))
    })

    socket.on("ice-candidate", async (candidate: RTCIceCandidateInit) => {
      await peerConnectionRef.current?.addIceCandidate(new RTCIceCandidate(candidate))
    })

    socket.on("user-disconnected", () => {
      toast({
        title: "User disconnected",
        description: "The other person has left the chat",
      })
      handleDisconnect()
    })

    socket.on("chat-message", (message: string) => {
      addMessage(message, "stranger")
    })

    return () => {
      socket.off("matched")
      socket.off("offer")
      socket.off("answer")
      socket.off("ice-candidate")
      socket.off("user-disconnected")
      socket.off("chat-message")
    }
  }, [socket, toast])

  // Auto-scroll chat to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Initialize camera and microphone
  const startMedia = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      })

      localStreamRef.current = stream

      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream
      }

      return true
    } catch (error) {
      console.error("Error accessing media devices:", error)
      toast({
        variant: "destructive",
        title: "Permission Error",
        description: "Please allow camera and microphone access to use this app",
      })
      return false
    }
  }

  // Create and configure RTCPeerConnection
  const createPeerConnection = () => {
    const configuration = {
      iceServers: [{ urls: "stun:stun.l.google.com:19302" }, { urls: "stun:stun1.l.google.com:19302" }],
    }

    const pc = new RTCPeerConnection(configuration)

    // Add local tracks to the connection
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => {
        pc.addTrack(track, localStreamRef.current!)
      })
    }

    // Handle incoming tracks (remote video)
    pc.ontrack = (event) => {
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = event.streams[0]
      }
    }

    // Send ICE candidates to the other peer
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        socket?.emit("ice-candidate", event.candidate)
      }
    }

    // Connection state changes
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "connected") {
        setIsConnected(true)
        setConnectionStatus("Connected")
      }
    }

    peerConnectionRef.current = pc
  }

  // Create and send an offer
  const createOffer = async () => {
    if (!peerConnectionRef.current) return

    try {
      const offer = await peerConnectionRef.current.createOffer()
      await peerConnectionRef.current.setLocalDescription(offer)
      socket?.emit("offer", offer)
    } catch (error) {
      console.error("Error creating offer:", error)
    }
  }

  // Create and send an answer
  const createAnswer = async () => {
    if (!peerConnectionRef.current) return

    try {
      const answer = await peerConnectionRef.current.createAnswer()
      await peerConnectionRef.current.setLocalDescription(answer)
      socket?.emit("answer", answer)
    } catch (error) {
      console.error("Error creating answer:", error)
    }
  }

  // Start looking for a chat partner
  const startChatting = async () => {
    setIsConnecting(true)
    const mediaStarted = await startMedia()

    if (mediaStarted) {
      setConnectionStatus("Looking for someone to chat with...")
      socket?.emit("find-match")
    } else {
      setIsConnecting(false)
    }
  }

  // Skip current chat partner and find a new one
  const skipPartner = () => {
    handleDisconnect()
    startChatting()
  }

  // Clean up connection when disconnecting
  const handleDisconnect = () => {
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close()
      peerConnectionRef.current = null
    }

    setIsConnected(false)
    setConnectionStatus("Disconnected")
    setMessages([])
  }

  // End the chat session completely
  const endChat = () => {
    socket?.emit("leave-chat")
    handleDisconnect()

    // Stop all tracks in the local stream
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop())
      localStreamRef.current = null
    }

    setIsConnecting(false)
  }

  // Toggle camera on/off
  const toggleCamera = () => {
    if (localStreamRef.current) {
      const videoTrack = localStreamRef.current.getVideoTracks()[0]
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled
        setIsCameraOn(videoTrack.enabled)
      }
    }
  }

  // Toggle microphone on/off
  const toggleMic = () => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0]
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled
        setIsMicOn(audioTrack.enabled)
      }
    }
  }

  // Add a new message to the chat
  const addMessage = (text: string, sender: "me" | "stranger") => {
    setMessages((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        text,
        sender,
        timestamp: new Date(),
      },
    ])
  }

  // Send a chat message
  const sendMessage = () => {
    if (!newMessage.trim() || !isConnected) return

    socket?.emit("chat-message", newMessage)
    addMessage(newMessage, "me")
    setNewMessage("")
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white shadow-sm py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <h1 className="text-xl font-bold text-blue-600">Random Video Chat</h1>
          <div className="text-sm px-3 py-1 rounded-full bg-blue-100 text-blue-800">{connectionStatus}</div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6 flex flex-col md:flex-row gap-4">
        <div className="flex-1 flex flex-col">
          <div className="relative bg-black rounded-lg overflow-hidden h-[60vh] md:h-[70vh] flex items-center justify-center">
            {isConnecting ? (
              <>
                {/* Remote video (large) */}
                <video ref={remoteVideoRef} autoPlay playsInline className="w-full h-full object-cover" />

                {/* Local video (small overlay) */}
                <div className="absolute bottom-4 right-4 w-1/4 h-1/4 md:w-1/5 md:h-1/5 bg-gray-800 rounded-lg overflow-hidden shadow-lg">
                  <video ref={localVideoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                </div>
              </>
            ) : (
              <div className="text-center p-8">
                <h2 className="text-white text-2xl mb-6">Ready to meet someone new?</h2>
                <Button size="lg" onClick={startChatting} className="bg-blue-600 hover:bg-blue-700">
                  Start Chatting
                </Button>
              </div>
            )}

            {!isConnected && isConnecting && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/70">
                <div className="text-center">
                  <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                  <p className="text-white text-lg">{connectionStatus}</p>
                </div>
              </div>
            )}
          </div>

          {isConnecting && (
            <VideoControls
              isCameraOn={isCameraOn}
              isMicOn={isMicOn}
              isConnected={isConnected}
              toggleCamera={toggleCamera}
              toggleMic={toggleMic}
              skipPartner={skipPartner}
              endChat={endChat}
              toggleChat={() => setIsChatOpen(!isChatOpen)}
              isChatOpen={isChatOpen}
            />
          )}
        </div>

        {isConnecting && isChatOpen && (
          <div className="w-full md:w-80 bg-white rounded-lg shadow-md flex flex-col h-[60vh] md:h-[70vh]">
            <div className="p-3 border-b flex justify-between items-center">
              <h3 className="font-medium">Chat</h3>
              <Button variant="ghost" size="icon" onClick={() => setIsChatOpen(false)} className="h-8 w-8">
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.length === 0 ? (
                <p className="text-gray-500 text-center text-sm py-8">No messages yet. Say hello!</p>
              ) : (
                messages.map((message) => <ChatMessage key={message.id} message={message} />)
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-3 border-t">
              <div className="flex gap-2">
                <Textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type a message..."
                  className="resize-none"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      sendMessage()
                    }
                  }}
                />
                <Button
                  onClick={sendMessage}
                  disabled={!isConnected || !newMessage.trim()}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Send
                </Button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}

