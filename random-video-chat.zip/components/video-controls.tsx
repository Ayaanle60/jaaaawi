"use client"

import { Button } from "@/components/ui/button"
import { Camera, CameraOff, Mic, MicOff, MessageSquare, SkipForward, PhoneOff } from "lucide-react"

type VideoControlsProps = {
  isCameraOn: boolean
  isMicOn: boolean
  isConnected: boolean
  isChatOpen: boolean
  toggleCamera: () => void
  toggleMic: () => void
  skipPartner: () => void
  endChat: () => void
  toggleChat: () => void
}

export default function VideoControls({
  isCameraOn,
  isMicOn,
  isConnected,
  isChatOpen,
  toggleCamera,
  toggleMic,
  skipPartner,
  endChat,
  toggleChat,
}: VideoControlsProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 mt-4 flex justify-between items-center">
      <div className="flex gap-2">
        <Button
          variant={isCameraOn ? "default" : "outline"}
          size="icon"
          onClick={toggleCamera}
          className={isCameraOn ? "bg-blue-600 hover:bg-blue-700" : ""}
        >
          {isCameraOn ? <Camera className="h-5 w-5" /> : <CameraOff className="h-5 w-5" />}
        </Button>

        <Button
          variant={isMicOn ? "default" : "outline"}
          size="icon"
          onClick={toggleMic}
          className={isMicOn ? "bg-blue-600 hover:bg-blue-700" : ""}
        >
          {isMicOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
        </Button>

        <Button
          variant={isChatOpen ? "default" : "outline"}
          size="icon"
          onClick={toggleChat}
          className={isChatOpen ? "bg-blue-600 hover:bg-blue-700" : ""}
        >
          <MessageSquare className="h-5 w-5" />
        </Button>
      </div>

      <div className="flex gap-2">
        <Button variant="outline" onClick={skipPartner} disabled={!isConnected} className="flex items-center gap-1">
          <SkipForward className="h-4 w-4" />
          <span>Next</span>
        </Button>

        <Button variant="destructive" onClick={endChat} className="flex items-center gap-1">
          <PhoneOff className="h-4 w-4" />
          <span>End</span>
        </Button>
      </div>
    </div>
  )
}

