import { cn } from "@/lib/utils"

type Message = {
  id: string
  text: string
  sender: "me" | "stranger"
  timestamp: Date
}

type ChatMessageProps = {
  message: Message
}

export default function ChatMessage({ message }: ChatMessageProps) {
  const isMe = message.sender === "me"

  return (
    <div className={cn("flex", isMe ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "max-w-[80%] rounded-lg px-3 py-2 text-sm",
          isMe ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-800",
        )}
      >
        <p>{message.text}</p>
        <p className={cn("text-xs mt-1", isMe ? "text-blue-200" : "text-gray-500")}>
          {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </p>
      </div>
    </div>
  )
}

